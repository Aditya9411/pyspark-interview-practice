# Databricks notebook source
# PySpark Interview Practice

from pyspark.sql.functions import (
    col, when, avg, max, row_number, split, explode,
    array_contains, to_date, months_between, current_date, floor
)
from pyspark.sql.window import Window

# COMMAND ----------
# SETUP
# Upload employees_pyspark_practice.csv to a Databricks Volume and update this path.
csv_path = "/Volumes/<catalog>/<schema>/<volume>/employees_pyspark_practice.csv"

df = (
    spark.read
    .option("header", True)
    .option("inferSchema", True)
    .csv(csv_path)
)

display(df)
df.printSchema()

# COMMAND ----------
# 1. Show only employees with salary > 60,000.
q1 = df.filter(col("salary") > 60000)
display(q1)

# COMMAND ----------
# 2. Show only name, department, and salary.
q2 = df.select("name", "department", "salary")
display(q2)

# COMMAND ----------
# 3. Find Data Engineering employees with salary > 70,000.
q3 = df.filter(
    (col("department") == "Data Engineering") &
    (col("salary") > 70000)
)
display(q3)

# COMMAND ----------
# 4. Create salary_category: >= 75,000 -> High, otherwise Normal.
q4 = df.withColumn(
    "salary_category",
    when(col("salary") >= 75000, "High").otherwise("Normal")
)
display(q4)

# COMMAND ----------
# 5. Find employees whose salary is NULL.
q5 = df.filter(col("salary").isNull())
display(q5)

# COMMAND ----------
# 6. Replace NULL salary with 0.
q6 = df.fillna({"salary": 0})
display(q6)

# COMMAND ----------
# 7. Count employees in each department.
q7 = df.groupBy("department").count()
display(q7)

# COMMAND ----------
# 8. Calculate average salary by department.
q8 = df.groupBy("department").agg(avg("salary").alias("avg_salary"))
display(q8)

# COMMAND ----------
# 9. Find maximum salary in each department.
q9 = df.groupBy("department").agg(max("salary").alias("max_salary"))
display(q9)

# COMMAND ----------
# 10. Sort employees by salary descending.
q10 = df.orderBy(col("salary").desc())
display(q10)

# COMMAND ----------
# 11. Find the top 3 highest-paid employees in each department.
salary_window = Window.partitionBy("department").orderBy(col("salary").desc())
q11 = (
    df.withColumn("rn", row_number().over(salary_window))
      .filter(col("rn") <= 3)
      .drop("rn")
)
display(q11)

# COMMAND ----------
# 12. For duplicate employee_ids, retain the latest updated_at record.
latest_window = Window.partitionBy("employee_id").orderBy(col("updated_at").desc())
clean_df = (
    df.withColumn("rn", row_number().over(latest_window))
      .filter(col("rn") == 1)
      .drop("rn")
)
display(clean_df)

# COMMAND ----------
# 13. Convert skills string into an array.
q13 = df.withColumn("skills_array", split(col("skills"), "\\|"))
display(q13)

# COMMAND ----------
# 14. Explode skills so each skill becomes a separate row.
q14 = q13.withColumn("skill", explode(col("skills_array")))
display(q14)

# COMMAND ----------
# 15. Find employees who have Spark as a skill.
q15 = q13.filter(array_contains(col("skills_array"), "Spark"))
display(q15)

# COMMAND ----------
# 16. Add years_of_service based on joining_date.
q16 = (
    df.withColumn("joining_date", to_date(col("joining_date")))
      .withColumn(
          "years_of_service",
          floor(months_between(current_date(), col("joining_date")) / 12)
      )
)
display(q16)

# COMMAND ----------
# 17. Repartition by department and inspect number of partitions.
q17 = df.repartition("department")
print("Partitions after repartition:", q17.rdd.getNumPartitions())

# COMMAND ----------
# 18. Coalesce to 2 partitions and compare.
q18 = q17.coalesce(2)
print("Before coalesce:", q17.rdd.getNumPartitions())
print("After coalesce:", q18.rdd.getNumPartitions())

# COMMAND ----------
# 19. Write the cleaned DataFrame as Delta.
# Update this path to match your Databricks Volume.
delta_path = "/Volumes/<catalog>/<schema>/<volume>/employees_delta"

# Uncomment after updating the path:
# (clean_df.write
#     .format("delta")
#     .mode("overwrite")
#     .save(delta_path))

# COMMAND ----------
# 20. Run explain() and identify Exchange/shuffle in the physical plan.
q20 = df.groupBy("department").agg(avg("salary").alias("avg_salary"))
q20.explain()

# Look for "Exchange" in the physical plan. It generally indicates data
# redistribution/shuffling between partitions.
